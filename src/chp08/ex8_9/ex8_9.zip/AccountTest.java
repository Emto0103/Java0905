package chp08.ex8_9;

public class AccountTest {
    public static void main(String[] args) {
        Account a = new Account("123-45", 10000);
        Account b = new Account("567-89", 10000);
        while (a.transfer(b, 3000)) {
            // Transfer 3000 until it can no longer be done
        }
        System.out.println(a.toString());
        System.out.println(b.toString());
    }
}

class Account {
    private String id;
    private int balance;

    public Account(String id, int balance) {
        this.id = id;
        this.balance = balance;
    }

    public String getId() {
        return id;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public boolean transfer(Account other, int amount) {
        if (amount <= balance) {
            this.balance -= amount;
            other.balance += amount;
            return true; // Transfer successful
        } else {
            return false; // Not enough balance
        }
    }

    @Override
    public String toString() {
        return "Account ID: " + id + ", Balance: " + balance;
    }
}
